package com.yarely.appifirebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
