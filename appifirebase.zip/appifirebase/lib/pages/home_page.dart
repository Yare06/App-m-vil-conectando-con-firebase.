
import 'package:flutter/material.dart';

import '../Services/firebase_services.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Material App Bar'),
        ),
        body: const Center(
          child: Text('Hello World'),
        ),
      ),
    );
  }
}
class Home extends StatefulWidget {
  const Home({
    super.key,
  });

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter with firebase'),
      ),
      body: FutureBuilder(
        future: getUsuarios(),
        builder: ((context, snapshot){
          if(snapshot.hasData == false){
            return const Center(
              child: CircularProgressIndicator(),
              );
              }
              else{
                return ListView.builder(
                  itemCount: snapshot.data?.length,
                  itemBuilder: ((context, index){
                    return ListTile(
                      title: Text(snapshot.data?[index]['nombre']),
                      subtitle: Text(snapshot.data?[index]['cuenta']),
                      leading: CircleAvatar(
                        child: Text(snapshot.data?[index]['nombre'].substring(0, 1)),
                      ),
                    );
                  })
                );
              }
          })
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.pushNamed(context, '/add');
        },
          child: const Icon(Icons.add),
      ),
    );
  }
}